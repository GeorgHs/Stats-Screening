class portfolioStatic:
    portfolioname = ''


class stockStatic:
    hist_data = []
    info_static = {}


class benchmarkStatic:
    hist_data = []
