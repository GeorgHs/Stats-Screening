from django.apps import AppConfig


class PortfolioScreenConfig(AppConfig):
    name = 'PortfolioScreen'
